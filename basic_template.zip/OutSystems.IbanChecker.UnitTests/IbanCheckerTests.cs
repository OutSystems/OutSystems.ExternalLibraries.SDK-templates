using IbanNet;
using IbanNet.Registry;
using NUnit.Framework;
using OutSystems.ExternalLibraries.SDK;

namespace OutSystems.IbanChecker.UnitTests; 

public class IbanCheckerTests {

    /// <summary>
    /// Tests if Iban structure is correctly created
    /// </summary>
    [Test]
    public void IbanStructureIsCorrectlyCreatedWhenGivenIban() {
        // Setup
        var parser = new IbanParser(IbanRegistry.Default);
        var iban = parser.Parse("NL91 ABNA 0417 1643 00");
        
        // Act
        var ibanStruct = new Iban(iban);
        
        // Assert
        Assert.Multiple(() => {
            Assert.That(ibanStruct.Country, Is.EqualTo(iban.Country.TwoLetterISORegionName));
            Assert.That(ibanStruct.BranchIdentifier, Is.EqualTo(iban.BranchIdentifier).Or.EqualTo(string.Empty));
            Assert.That(ibanStruct.BankIdentifier, Is.EqualTo(iban.BankIdentifier).Or.EqualTo(string.Empty));
            Assert.That(ibanStruct.Bban, Is.EqualTo(iban.Bban));
        });
    }

    /// <summary>
    /// Tests if IbanChecker correctly parses valid Iban
    /// </summary>
    [Test]
    public void IbanCheckerCorrectlyParsesIban() {
        // Setup
        var parser = new IbanParser(IbanRegistry.Default);
        var iban = parser.Parse("NL91 ABNA 0417 1643 00");
        var checker = new IbanChecker();
        
        // Act
        var ibanStruct = checker.Parse("NL91 ABNA 0417 1643 00");
        
        // Assert
        Assert.Multiple(() => {
            Assert.That(ibanStruct, Is.Not.Null);
            Assert.That(ibanStruct?.Country, Is.EqualTo(iban.Country.TwoLetterISORegionName));
            Assert.That(ibanStruct?.BranchIdentifier, Is.EqualTo(iban.BranchIdentifier).Or.EqualTo(string.Empty));
            Assert.That(ibanStruct?.BankIdentifier, Is.EqualTo(iban.BankIdentifier).Or.EqualTo(string.Empty));
            Assert.That(ibanStruct?.Bban, Is.EqualTo(iban.Bban));
        });
    }
    
    /// <summary>
    /// Tests if Iban class is decorated with OSStructureAttribute
    /// </summary>
    [Test]
    public void IbanStructureHasOSStructureAttribute() {
        // Assert
        Assert.That(Attribute.GetCustomAttribute(typeof(Iban), typeof(OSStructureAttribute)), Is.Not.Null);
    }

    /// <summary>
    /// Tests if IIbanChecker interface is decorated with OSInterfaceAttribute
    /// </summary>
    [Test]
    public void IbanCheckerInterfaceHasOSInterfaceAttribute() {
        // Assert
        Assert.That(Attribute.GetCustomAttribute(typeof(IIbanChecker), typeof(OSInterfaceAttribute)), Is.Not.Null);
    }
}